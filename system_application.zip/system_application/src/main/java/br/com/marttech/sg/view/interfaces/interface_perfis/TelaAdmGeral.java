package br.com.marttech.sg.view.interfaces.interface_perfis;

import br.com.marttech.sg.view.App;
import br.com.marttech.sg.view.interfaces.menu.BotaoMenu;
import br.com.marttech.sg.view.interfaces.menu.Menu;
import br.com.marttech.sg.view.interfaces.telas_funcoes.cadastro.TelaCadastro;
import br.com.marttech.sg.view.interfaces.telas_funcoes.inicio.TelaInicio;
import br.com.marttech.sg.view.interfaces.telas_funcoes.meus_dados.TelaMeusDados;
import br.com.marttech.sg.view.interfaces.telas_funcoes.minha_conta.TelaMinhaConta;
import br.com.marttech.sg.view.interfaces.telas_funcoes.usuarios.telas.TelaUsuarios;
import javafx.application.Platform;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;

public class TelaAdmGeral extends GridPane{
	
	private Menu menu;
	private StackPane conteudo;
	
	private TelaInicio telaInicio;
	private TelaMeusDados telaMeusDados;
	private TelaMinhaConta telaMinhaConta;
	private TelaCadastro telaCadastro;
	//TODO - REFAZER
	public static TelaUsuarios telaUsuarios;
	
	public TelaAdmGeral() {
		setAlignment(Pos.TOP_LEFT);
		construirMenu();
		construirPaginasConteudo();
		
		getColumnConstraints().addAll(coluna(307), coluna(1600));
		getRowConstraints().addAll(linha(), linha(), linha(), linha(), linha(),
				linha(), linha());
		
		add(menu, 0, 0, 1, 7);
		add(conteudo, 1, 0, 1, 7);
		
		setMinHeight(700);
		setMinWidth(1100);
		setMaxHeight(USE_COMPUTED_SIZE);
		setMaxWidth(USE_COMPUTED_SIZE);
	}
	
	private ColumnConstraints coluna(double width) {
		ColumnConstraints cc = new ColumnConstraints();
		cc.setMinWidth(USE_COMPUTED_SIZE);
		cc.setMaxWidth(USE_COMPUTED_SIZE);
		cc.setPrefWidth(width);
		cc.setPercentWidth(-1);
		cc.setHalignment(HPos.LEFT);
		cc.setHgrow(Priority.ALWAYS);
		cc.setFillWidth(true);
		return cc;
	}
	
	private RowConstraints linha() {
		RowConstraints rc = new RowConstraints();
		rc.setMinHeight(USE_COMPUTED_SIZE);
		rc.setMaxHeight(USE_COMPUTED_SIZE);
		rc.setPrefHeight(162);
		rc.setPercentHeight(-1);
		rc.setVgrow(Priority.ALWAYS);
		rc.setFillHeight(true);
		return rc;
	}
	
	private void construirMenu() {
		menu = new Menu();
		BotaoMenu botaoInicio = menu.getBotao0();
		BotaoMenu botaoMeusDados = menu.getBotao1();
		BotaoMenu botaoMinhaConta = menu.getBotao2();
		BotaoMenu botaoCadastro = menu.getBotao3();
		BotaoMenu botaoUsuarios = menu.getBotao4();
		BotaoMenu botaoSair = menu.getBotao6();
		
		botaoInicio.setOnAction(e -> {
			conteudo.getChildren().get(buscarTela(telaInicio)).toFront(); 
			menu.setUltimoBotaoClicado(botaoInicio);
		});
		botaoMeusDados.setOnAction(e -> {
			conteudo.getChildren().get(buscarTela(telaMeusDados)).toFront(); 
			menu.setUltimoBotaoClicado(botaoMeusDados);
		});
		botaoMinhaConta.setOnAction(e -> {
			conteudo.getChildren().get(buscarTela(telaMinhaConta)).toFront();
			menu.setUltimoBotaoClicado(botaoMinhaConta);
		});
		botaoCadastro.setOnAction(e -> {
			conteudo.getChildren().get(buscarTela(telaCadastro)).toFront();
			menu.setUltimoBotaoClicado(botaoCadastro);
		});
		botaoUsuarios.setOnAction(e -> {
			conteudo.getChildren().get(buscarTela(telaUsuarios)).toFront();
			menu.setUltimoBotaoClicado(botaoUsuarios);
		});
		botaoSair.setOnAction(e -> App.reset());
	}
	
	private int buscarTela(Object componente) {
		return conteudo.getChildren().indexOf(componente);
	}
	
	private void construirPaginasConteudo() {
		conteudo = new StackPane();
		conteudo.setPrefHeight(1080);
		conteudo.setPrefWidth(1800);
		conteudo.setMaxHeight(USE_COMPUTED_SIZE);
		conteudo.setMaxWidth(USE_COMPUTED_SIZE);
		telaInicio = new TelaInicio();
		telaMeusDados = new TelaMeusDados();
		telaMinhaConta = new TelaMinhaConta();
		telaCadastro = new TelaCadastro();
		telaUsuarios = new TelaUsuarios();
		conteudo.getChildren().addAll(telaMeusDados, telaMinhaConta, telaCadastro, telaUsuarios, telaInicio);
		
		Thread t = new Thread(() ->{
			try {
				Platform.runLater(() -> {
				});
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		
		t.setPriority(10);
		//t.start();
	}
	
	public void reset() {
		telaUsuarios.reset();
	}
	
	public void reload() {
		Thread t = new Thread(() ->{
			try {
				Platform.runLater(() -> {
					menu.reload();
					telaInicio.reload();
					telaMeusDados.reload();
					telaMinhaConta.reload();
					telaCadastro.reload();
					telaUsuarios.reload();
				});
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		
		t.setPriority(10);
		t.start();
	}
}
