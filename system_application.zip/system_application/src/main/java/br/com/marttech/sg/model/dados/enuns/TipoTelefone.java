package br.com.marttech.sg.model.dados.enuns;

public enum TipoTelefone {

	CEL, RES
}
