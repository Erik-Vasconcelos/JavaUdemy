package br.com.marttech.sg.model.dados.enuns;

public enum Estado {
	MA, PI, CE, RN, PB, PE, AL, SE, BA;
}
