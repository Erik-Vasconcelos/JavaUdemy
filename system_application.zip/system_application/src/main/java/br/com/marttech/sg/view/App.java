
package br.com.marttech.sg.view;

import br.com.marttech.sg.controller.CarregarApp;
import br.com.marttech.sg.model.memoria.ServidorMemory;
import br.com.marttech.sg.view.interfaces.interface_perfis.TelaAdmGeral;
import br.com.marttech.sg.view.loading.TelaCarregamento;
import br.com.marttech.sg.view.login.Login;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class App extends Application {

	public static Stage janelaLogin;
	private static Scene telaLogin;
	private static Scene telaCarregamento;
	
	private static TelaCarregamento tela;
	
	public static Stage janelaPrincipal;
	private static Scene telaPrincipal;
	
	private static TelaAdmGeral telaAdm;

	@Override
	public void start(Stage primaryStage) throws Exception {
		janelaLogin = primaryStage;
	
		/*construirCaregamento();
		setTelaCarregamento();*/
		construirLogin();
		setTelaLogin();
		configJanelaLogin();
		
		
		
		/*Thread t1 = new Thread(() -> {
			double cont = 0.0;
			while(cont < 1) {
				try {
					if (cont < 0.7) {
						Thread.sleep(70);
					}else {
						Thread.sleep(10);
					}
					cont += 0.01;
					tela.setProgress(cont);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		t1.setDaemon(true);
		t1.start();*/
		
		//tela.setProgress(0.5);
		
		Thread t = new Thread(() -> {
			try {
				CarregarApp.startHibernate();
				/*Platform.runLater(() -> {
					configJanelaPrincipal();
				});*/
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		
		t.setDaemon(true);
		t.start();
		
	}

	public static void main(String[] args) {
		launch(args);
	}
	
	/*----------------------------Configura��o de janelas---------------------------------*/
	
	private static void configJanelaLogin() {
		janelaLogin.getIcons().add(new Image("file:///D:/Java_Udemy/system_application/src/main/java/br/com/marttech/sg/view/imagens/diplomado.png"));
		janelaLogin.setTitle("Sistema Gest�o");
		janelaLogin.setResizable(false);
		janelaLogin.setMaximized(false);
		janelaLogin.centerOnScreen();
		//janelaLogin.setAlwaysOnTop(true); deixa a janela em cima de outra
	}
	
	private static void configJanelaPrincipal() {
		janelaPrincipal = new Stage();
		janelaPrincipal.getIcons().add(new Image("file:///D:/Java_Udemy/system_application/src/main/java/br/com/marttech/sg/view/imagens/diplomado.png"));
		janelaPrincipal.setTitle("Sistema Gest�o");
		janelaPrincipal.setMaximized(true);
		janelaPrincipal.setResizable(true);
		janelaPrincipal.centerOnScreen();
	}
	
	/*----------------------------Fechamento das janelas---------------------------------*/
	
	private static void fecharJanelaLogin() {
		janelaLogin.getScene().getWindow().hide(); //tenta ocultar esta janela definindo a visibilidade como falsa
	}
	
	private static void fecharJanelaPrincipal() {
		janelaPrincipal.getScene().getWindow().hide();
		telaAdm.reset();
	}
	
	/*----------------------------Constru��o das cenas---------------------------------*/
	
	public static void construirLogin() {
		telaLogin = new Scene(new Login(), 420, 520);
	}
	
	private static void construirCaregamento() {
		tela = new TelaCarregamento();
		telaCarregamento = new Scene(tela, 480, 320);
	}
	
	public static void contruirTelaInicio() {
		if(telaPrincipal == null) {
			telaAdm = new TelaAdmGeral();
			GridPane raiz = telaAdm;
			telaPrincipal = new Scene(raiz);
		}
	}
	
	/*----------------------------Reset da aplica��o---------------------------------*/
	
	public static void reset() {
		ServidorMemory.resetMemory();
		fecharJanelaPrincipal();
		setTelaLogin();
	}
	
	/*-------------------------M�todos de Settar as cenas------------------------------*/
	
	public static void setTelaCarregamento() {
		if(janelaLogin.getScene() == null) {
			janelaLogin.setScene(telaCarregamento);
		}
		
		janelaLogin.initStyle(StageStyle.UNDECORATED);
		janelaLogin.centerOnScreen();
		janelaLogin.show();
	}
	
	public static void setTelaLogin() {
		if(janelaLogin.getScene() == null) {
			janelaLogin.setScene(telaLogin);
		}
		janelaLogin.show();
	}

	public static void setTelaInicio() {
		fecharJanelaLogin();
		
		if (janelaPrincipal == null) {
			configJanelaPrincipal();
		}else {
			telaAdm.reload();
		}
		
		janelaPrincipal.setScene(telaPrincipal);
		janelaPrincipal.show();
	}
	
	private static void setProgress(double value) {
	}

}
