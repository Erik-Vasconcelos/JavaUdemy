package br.com.marttech.sg.view.interfaces.telas_funcoes.usuarios.agrupador;

public enum TipoConsulta {
	PADRAO, FILTRO;
}
