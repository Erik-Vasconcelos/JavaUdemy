package br.com.marttech.sg.model.perfis.enuns;

public enum Cargo {
	
	DIRETOR, PROFESSOR, SECRETARIO;
}
