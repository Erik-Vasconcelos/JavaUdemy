package br.com.marttech.sg.view.interfaces.menu;


import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import br.com.marttech.sg.controller.MenuController;
import br.com.marttech.sg.model.dto.ServidorDTO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;

public class Menu extends VBox{
	
	private Label titulo;
	private Circle imgUsuario;
	private Button botaoMinhaConta;
	private Label nomeUsuario;
	private TextField pesquisa;
	private BotaoMenu botao0;
	private BotaoMenu botao1;
	private BotaoMenu botao2;
	private BotaoMenu botao3;
	private BotaoMenu botao4;
	private BotaoMenu botao5;
	
	private BorderPane agrupadorUsuario;
	
	private BotaoMenu ultimoBotao = new BotaoMenu();
	private BotaoMenu ultimoBotaoClicado;
	
	private List<BotaoMenu> botoes;
	
	public Menu() {
		setAlignment(Pos.TOP_CENTER);
		setPadding(new Insets(8));
		setSpacing(4);
		String css = getClass().getResource("Menu.css").toExternalForm();
		getStylesheets().add(css);
		getStyleClass().add("Content");
		construirComponentes();
		
		getStylesheets().add("https://fonts.googleapis.com/css2?family=Rajdhani");
		
		Label label = new Label("Erik Vasconcelos\n�2022");
		label.getStyleClass().add("Label");
		getChildren().addAll(titulo, agrupadorUsuario, pesquisa, botao0, botao1, botao2, botao3, botao4, botao5, label);
	}
	
	private void construirComponentes() {
		titulo = new Label("Sistema Gestao");
		imgUsuario = new Circle(44, 44, 22);
		botaoMinhaConta = new Button("",  new ImageView(new Image("C:/Users/erikv/Downloads/icone-usuario.png")));
		nomeUsuario = new Label();
		pesquisa = new TextField();
		botao0 = new BotaoMenu("Inicio", "C:/Users/erikv/Downloads/casa.png");
		botao1 = new BotaoMenu("Meus dados", "C:/Users/erikv/Downloads/dados-pessoais.png");
		botao2 = new BotaoMenu("Minha Conta", "C:/Users/erikv/Downloads/minha-conta.png");
		botao3 = new BotaoMenu("Cadastrar Usuario", "C:/Users/erikv/Downloads/novo-Usuario.png");
		botao4 = new BotaoMenu("Usuarios", "C:/Users/erikv/Downloads/usuarios.png");
		botao5 = new BotaoMenu("Sair", "C:/Users/erikv/Downloads/sair (1).png");
		
		botoes = new ArrayList<>(Arrays.asList(botao0, botao1, botao2, botao3, botao4, botao5));
		
		configContainerUsuario();
		setUltimoBotaoClicado(botao0);
		
		titulo.getStyleClass().add("Titulo");
		pesquisa.getStyleClass().add("Pesquisa");
		
		pesquisa.setPromptText("Buscar Menu");
		
		setMaxHeight(USE_COMPUTED_SIZE);
		setMaxWidth(USE_COMPUTED_SIZE);
	}
	
	private void configContainerUsuario() {
		agrupadorUsuario = new BorderPane();
		agrupadorUsuario.getStyleClass().add("Content-Usuario");
		agrupadorUsuario.setPadding(new Insets(0, 8, 0, 0));
		
		
		//-----------Configurando componentes------------
		imgUsuario = new Circle(44, 44, 22);
		nomeUsuario = new Label();
		construirBotaoMinhaconta();
		
		botaoMinhaConta.getStyleClass().add("Botao-Icone-Usuario");
		nomeUsuario.getStyleClass().add("Label-Nome-Usuario");
		
		/*--------------Settando dados---------------*/
		setDadosContainerUsuario();
		
		botaoMinhaConta.setOnAction(e -> botao2.fire());
		
		agrupadorUsuario.setLeft(imgUsuario);
		agrupadorUsuario.setRight(botaoMinhaConta);
		agrupadorUsuario.setCenter(nomeUsuario);
		agrupadorUsuario.setAlignment(botaoMinhaConta, Pos.CENTER_RIGHT);
		
	}
	
	private void setDadosContainerUsuario() {
		ServidorDTO servidor = MenuController.getDadosContent();
		
		if(servidor.getImagem() != null) {
			InputStream inputStream = new ByteArrayInputStream(servidor.getImagem());
			imgUsuario.setFill(new ImagePattern(new Image(inputStream)));
		}
		
		nomeUsuario.setText(servidor.getNome());
	}
	
	private void construirBotaoMinhaconta() {
		botaoMinhaConta = new Button("",  new ImageView(
				new Image("C:/Users/erikv/Downloads/icone-usuario.png")));
		botaoMinhaConta.setCursor(Cursor.HAND);
	}
	
	public void reload() {
		setDadosContainerUsuario();
	}

	public Label getLabel() {
		return titulo;
	}
	
	public BotaoMenu getBotao0() {
		return botao0;
	}

	public BotaoMenu getBotao1() {
		return botao1;
	}

	public BotaoMenu getBotao2() {
		return botao2;
	}

	public BotaoMenu getBotao3() {
		return botao3;
	}

	public Label getTitulo() {
		return titulo;
	}

	public TextField getPesquisa() {
		return pesquisa;
	}

	public BotaoMenu getBotao4() {
		return botao4;
	}

	public BotaoMenu getBotao6() {
		return botao5;
	}

	public BotaoMenu getUltimoBotaoClicado() {
		return ultimoBotaoClicado;
	}

	public void setUltimoBotaoClicado(BotaoMenu ultimoBotaoClicado) {
		this.ultimoBotao = this.ultimoBotaoClicado;
		this.ultimoBotaoClicado = ultimoBotaoClicado;
	}

	@Override
	public int hashCode() {
		return Objects.hash(botao0, botao1, botao2, botao3, botao4, botao5, botao5, botoes, ultimoBotaoClicado);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Menu other = (Menu) obj;
		return Objects.equals(botao0, other.botao0) && Objects.equals(botao1, other.botao1)
				&& Objects.equals(botao2, other.botao2) && Objects.equals(botao3, other.botao3)
				&& Objects.equals(botao4, other.botao4) && Objects.equals(botao5, other.botao5)
				&& Objects.equals(botao5, other.botao5) && Objects.equals(botoes, other.botoes)
				&& Objects.equals(ultimoBotaoClicado, other.ultimoBotaoClicado);
	}
	
}
