
module exerciciosfx {
	requires javafx.controls;
	requires javafx.fxml;
	
	opens basico;
	opens layout;
	opens fxml;
	opens layout.exercicio;
}